class Pokemon {
    constructor(id, moves) {
        const data = pokemonData[id];
        this.id = id;
        this.name = data.name;
        this.types = data.types;
        this.ability = data.ability;
        this.baseStats = data.stats;
        this.icon = data.icon;

        // Current Stats (copy base stats)
        this.maxHp = this.baseStats.hp;
        this.hp = this.maxHp;
        this.stats = { ...this.baseStats }; // Effective stats for battle

        // Stat Stages (-6 to +6)
        this.stages = {
            atk: 0, def: 0, spa: 0, spd: 0, spe: 0,
            acc: 0, eva: 0
        };

        // Moves (List of move objects from move_list.js)
        this.moves = moves.slice(0, 4);

        // Status
        this.status = null; // { name: 'burn'|'paralysis'|..., count: 0 (for sleep) }
        this.statusParams = {}; // Extra params for status (e.g., sleep turn count)

        // Volatile Status (cleared on switch)
        this.volatile = {
            confusion: 0, // turns remaining
            flinch: false,
            bound: 0,
            leechSeed: false,
            drowsy: 0, // for yawn
            protect: false, // for detection/protect
            protectCount: 0 // consecutive protects
        };
    }

    getStat(statName) {
        let value = this.stats[statName];

        // Stage Multipliers
        const stage = this.stages[statName] || 0;
        let multiplier = 1.0;
        if (stage > 0) multiplier = (2 + stage) / 2;
        if (stage < 0) multiplier = 2 / (2 - stage);

        // Special Status Effects on Stats
        if (this.status?.name === 'paralysis' && statName === 'spe') multiplier *= 0.5;
        if (this.status?.name === 'burn' && statName === 'atk') multiplier *= 0.5;

        return Math.floor(value * multiplier);
    }

    applyStage(stat, amount) {
        this.stages[stat] = Math.max(-6, Math.min(6, this.stages[stat] + amount));
        return this.stages[stat];
    }
}

class Battle {
    constructor(player1Team, player2Team, onLog) {
        this.p1 = {
            name: "Player 1",
            team: player1Team,
            active: player1Team[0],
            activeIndex: 0
        };
        this.p2 = {
            name: "Player 2",
            team: player2Team,
            active: player2Team[0],
            activeIndex: 0
        };
        this.turn = 0;
        this.weather = 'none'; // none, sun, rain, sand, hail
        this.weatherDuration = 0;
        this.fieldEffects = {};
        this.logCallback = onLog || console.log;

        this.log(`バトル開始！`);
        this.triggerEntryAbilities(this.p1.active);
        this.triggerEntryAbilities(this.p2.active);
    }

    log(message) {
        this.logCallback(message);
    }

    // Resolves a turn where both players have selected an action
    // action: { type: 'move'|'switch', index: 0-3 }
    resolveTurn(p1Action, p2Action) {
        this.turn++;
        this.log(`--- ターン ${this.turn} ---`);

        const p1Pokemon = this.p1.active;
        const p2Pokemon = this.p2.active;

        // Reset turn-based flags
        p1Pokemon.volatile.flinch = false;
        p2Pokemon.volatile.flinch = false;
        p1Pokemon.volatile.protect = false;
        p2Pokemon.volatile.protect = false;

        // 1. Switches
        if (p1Action.type === 'switch') this.performSwitch(this.p1, p1Action.index);
        if (p2Action.type === 'switch') this.performSwitch(this.p2, p2Action.index);

        // If both switched, turn ends (simplified flow)
        if (p1Action.type === 'switch' && p2Action.type === 'switch') {
            this.endTurn();
            return;
        }

        // 2. Move Order
        // If one switched, the other attacks. If both attack, calculate order.
        let first = null;
        let second = null;
        let p1Move = p1Action.type === 'move' ? p1Pokemon.moves[p1Action.index] : null;
        let p2Move = p2Action.type === 'move' ? p2Pokemon.moves[p2Action.index] : null;

        if (p1Action.type === 'move' && p2Action.type === 'move') {
            // Priority check
            const p1Pri = p1Move.priority || 0;
            const p2Pri = p2Move.priority || 0;

            if (p1Pri > p2Pri) { first = { p: this.p1, m: p1Move }; second = { p: this.p2, m: p2Move }; }
            else if (p2Pri > p1Pri) { first = { p: this.p2, m: p2Move }; second = { p: this.p1, m: p1Move }; }
            else {
                // Speed check
                const s1 = p1Pokemon.getStat('spe');
                const s2 = p2Pokemon.getStat('spe');
                if (s1 > s2) { first = { p: this.p1, m: p1Move }; second = { p: this.p2, m: p2Move }; }
                else if (s2 > s1) { first = { p: this.p2, m: p2Move }; second = { p: this.p1, m: p1Move }; }
                else {
                    // Speed tie: Random
                    if (Math.random() < 0.5) { first = { p: this.p1, m: p1Move }; second = { p: this.p2, m: p2Move }; }
                    else { first = { p: this.p2, m: p2Move }; second = { p: this.p1, m: p1Move }; }
                }
            }
        } else if (p1Action.type === 'move') {
            first = { p: this.p1, m: p1Move };
        } else if (p2Action.type === 'move') {
            first = { p: this.p2, m: p2Move };
        }

        // Execution
        if (first && !this.checkFainted(first.p.active)) this.useMove(first.p, this.getOpponent(first.p), first.m);
        if (second && !this.checkFainted(second.p.active)) this.useMove(second.p, this.getOpponent(second.p), second.m);

        this.endTurn();
    }

    getOpponent(player) {
        return player === this.p1 ? this.p2 : this.p1;
    }

    performSwitch(player, index) {
        const oldMon = player.active;
        const newMon = player.team[index];

        if (oldMon.hp <= 0) {
            this.log(`${player.name}は ${oldMon.name} から ${newMon.name} に交代した！`);
        } else {
            this.log(`${player.name}は ${oldMon.name} を引っ込めて ${newMon.name} を繰り出した！`);
        }

        player.active = newMon;
        player.activeIndex = index;

        // Reset volatile status
        oldMon.volatile = { ...player.active.volatile }; // Actually should reset for the OLD one entering box, but JS object reference handles active. 
        // Logic fix: reset volatile for the one leaving.
        oldMon.volatile = { confusion: 0, flinch: false, bound: 0, leechSeed: false, drowsy: 0, protect: false, protectCount: 0 };

        this.triggerEntryAbilities(newMon);
    }

    triggerEntryAbilities(pokemon) {
        // Simple entry effects
        this.log(`${pokemon.name} (特性: ${pokemon.ability.name})`);
    }

    useMove(attacker, defender, move) {
        const atkMon = attacker.active;
        const defMon = defender.active;

        this.log(`${atkMon.name} の ${move.name}！`);

        // 1. Check Status (Sleep, Paralysis, Confusion, Freeze)
        if (!this.canMove(atkMon)) return;

        // 2. Accuracy Check
        if (move.accuracy !== null) { // null = sure hit
            // Formulas usually involve stages, but simplified here:
            // TODO: Apply stat stages for accuracy/evasion if spec requires detailed formula
            if (Math.random() * 100 > move.accuracy) {
                this.log(`しかし ${defMon.name} には当たらなかった！`);
                return;
            }
        }

        // 3. Category Logic
        if (move.category === '変化') { // Status Move
            this.applyStatusMove(atkMon, defMon, move);
        } else { // Physical / Special
            this.applyDamageMove(atkMon, defMon, move);
        }
    }

    canMove(pokemon) {
        if (pokemon.hp <= 0) return false;

        // Freeze
        if (pokemon.status?.name === 'freeze') {
            if (Math.random() < 0.25) {
                pokemon.status = null;
                this.log(`${pokemon.name} のこおりがとけた！`);
            } else {
                this.log(`${pokemon.name} はこおってしまって動けない！`);
                return false;
            }
        }

        // Sleep
        if (pokemon.status?.name === 'sleep') {
            pokemon.statusParams.sleepTurns--;
            if (pokemon.statusParams.sleepTurns <= 0) {
                pokemon.status = null;
                this.log(`${pokemon.name} は目を覚ました！`);
            } else {
                this.log(`${pokemon.name} はぐうぐう眠っている...`);
                // Sleep talk could go here
                return false;
            }
        }

        // Paralysis
        if (pokemon.status?.name === 'paralysis') {
            if (Math.random() < 0.25) {
                this.log(`${pokemon.name} は体がしびれて動けない！`);
                return false;
            }
        }

        // Confusion
        if (pokemon.volatile.confusion > 0) {
            pokemon.volatile.confusion--;
            this.log(`${pokemon.name} は混乱している！`);
            if (Math.random() < 0.33) {
                // Self hit
                // Power 40 physical
                const damage = this.calculateDamageSimple(40, pokemon, pokemon, '物理', 'normal');
                pokemon.hp -= damage;
                this.log(`わけもわからず自分を攻撃した！ (${damage}ダメージ)`);
                if (pokemon.volatile.confusion === 0) this.log(`${pokemon.name} の混乱がとけた！`);
                return false;
            }
            if (pokemon.volatile.confusion === 0) this.log(`${pokemon.name} の混乱がとけた！`);
        }

        // Flinch
        if (pokemon.volatile.flinch) {
            this.log(`${pokemon.name} はひるんで動けない！`);
            return false;
        }

        return true;
    }

    calculateDamageSimple(power, attacker, defender, category, type) {
        // Internal helper for self-hit
        // Same formula but simplified args
        // Damage= ( ( 22* 技の威力* A / D ) / 50 + 2)
        const a = attacker.getStat('atk');
        const d = defender.getStat('def');
        return Math.floor(((22 * power * a / d) / 50 + 2));
    }

    applyDamageMove(attacker, defender, move) {
        // Damage Formula
        // Damage= ( ( 22* 技の威力* 技の種類（物理技、特殊技）に対する攻撃側のポケモンの攻撃の能力値（こうげき、とくこう）/　技の種類（物理技、特殊技）に対する受ける側のポケモンの防御の能力値（ぼうぎょ、とくぼう）)  / 50+ 2) * 持ち物や特性、天気などによる威力補正

        const isPhysical = move.category === '物理';

        let a = isPhysical ? attacker.getStat('atk') : attacker.getStat('spa');
        let d = isPhysical ? defender.getStat('def') : defender.getStat('spd');

        // Apply Weather/Crit/Burn to stats if needed, or to final damage? 
        // Spec: "やけど...こうげきの実数値が半分になる" -> Handled in getStat()
        // "いわタイプのポケモンのとくぼうが1.5倍になる" (Sandstorm) -> Handle here or getStat
        if (this.weather === 'sand' && defender.types.includes('いわ') && !isPhysical) {
            d = Math.floor(d * 1.5);
        }

        let damage = Math.floor((22 * move.power * a / d) / 50 + 2);

        // Modifiers
        // 1. Weather
        if (this.weather === 'sun') {
            if (move.type === 'ほのお') damage = Math.floor(damage * 1.5);
            if (move.type === 'みず') damage = Math.floor(damage * 0.5);
        }
        if (this.weather === 'rain') {
            if (move.type === 'みず') damage = Math.floor(damage * 1.5);
            if (move.type === 'ほのお') damage = Math.floor(damage * 0.5);
        }

        // 2. Crit (1/24 seems standard for gen 9, spec doesn't specify rate approx)
        // Spec only mentions abilities increasing crit rate.
        let critStage = 0;
        if (attacker.ability.name === 'きょううん') critStage += 1;
        if (move.effect?.crit_rate) critStage += move.effect.crit_rate;
        // Basic probability: 0: 1/24 (4.16%), 1: 1/8 (12.5%), 2: 1/2 (50%), 3+: 100%
        let critChance = 0.0416;
        if (critStage === 1) critChance = 0.125;
        if (critStage === 2) critChance = 0.5;
        if (critStage >= 3) critChance = 1.0;

        // Ability: ひとでなし (Critical on poison)
        if (attacker.ability.name === 'ひとでなし' && (defender.status?.name === 'poison' || defender.status?.name === 'bad_poison')) {
            critChance = 1.0;
        }
        // Ability: カブトアーマー (No crit)
        if (defender.ability.name === 'カブトアーマー') critChance = 0;

        let isCrit = Math.random() < critChance;
        if (isCrit) {
            damage = Math.floor(damage * 1.5);
            this.log("急所にあたった！");
        }

        // 3. Random (0.85 - 1.00)
        const random = 0.85 + Math.random() * 0.15;
        damage = Math.floor(damage * random);

        // 4. STAB (Same Type Attack Bonus)
        if (attacker.types.includes(move.type)) {
            damage = Math.floor(damage * 1.5);
        }

        // 5. Type Effectiveness
        let typeEffectiveness = 1.0;
        if (typeChart[move.type]) {
            defender.types.forEach(defType => {
                const eff = typeChart[move.type][defType];
                if (eff !== undefined) typeEffectiveness *= eff;
            });
        }

        // Ability: あついしぼう (Thick Fat)
        if (defender.ability.name === 'あついしぼう' && (move.type === 'ほのお' || move.type === 'こおり')) {
            typeEffectiveness *= 0.5;
        }
        // Ability: すいほう (Water Bubble)
        if (defender.ability.name === 'すいほう' && move.type === 'ほのお') {
            typeEffectiveness *= 0.5;
        }
        if (attacker.ability.name === 'すいほう' && move.type === 'みず') {
            damage = Math.floor(damage * 2); // Double power for water moves
        }

        damage = Math.floor(damage * typeEffectiveness);

        if (typeEffectiveness > 1) this.log("効果はばつぐんだ！");
        if (typeEffectiveness < 1 && typeEffectiveness > 0) this.log("効果はいまひとつだ...");
        if (typeEffectiveness === 0) {
            this.log("効果がないようだ...");
            damage = 0;
        }

        // Apply Damage
        defender.hp -= damage;
        if (defender.hp < 0) defender.hp = 0;
        this.log(`${defender.name} に ${damage} のダメージ！`);

        // Side Effects
        if (defender.hp > 0 && move.effect) {
            this.resolveMoveEffects(attacker, defender, move, damage);
        }
    }

    applyStatusMove(attacker, defender, move) {
        this.log(`${move.name} を使った！ (変化技)`);
        // Status Moves Logic
        // Very simplified parsing of the 'effect' object in move_list.js
        const effect = move.effect;
        if (!effect) return;

        if (effect.stat_change) {
            effect.stat_change.forEach(change => {
                const target = change.target === 'self' ? attacker : defender;
                if (Math.random() * 100 <= change.chance) {
                    const currentStage = target.applyStage(change.stat, change.stage);
                    const direction = change.stage > 0 ? "あがった" : "さがった";
                    const intensity = Math.abs(change.stage) > 1 ? "ぐーんと" : "";
                    this.log(`${target.name} の ${change.stat} が ${intensity}${direction}！`);
                }
            });
        }

        if (effect.status_ailment) {
            this.tryInflictStatus(defender, effect.status_ailment.name, effect.status_ailment.chance);
        }

        if (effect.recovery) {
            if (effect.recovery === "50%") {
                const healAmount = Math.floor(attacker.maxHp / 2);
                attacker.hp = Math.min(attacker.maxHp, attacker.hp + healAmount);
                this.log(`${attacker.name} の体力が回復した！`);
            }
            if (effect.recovery === "100%") { // Rest
                attacker.hp = attacker.maxHp;
                this.log(`${attacker.name} は体力を全回復した！`);
            }
        }
    }

    resolveMoveEffects(attacker, defender, move, damageDealt) {
        const effect = move.effect;
        // Recoil
        if (effect.recoil) {
            if (effect.recoil === "33%") {
                const recoil = Math.floor(damageDealt / 3);
                attacker.hp = Math.max(0, attacker.hp - recoil);
                this.log(`${attacker.name} は反動を受けた！ (${recoil})`);
            }
        }
        // Stat change secondary effect
        if (effect.stat_change) {
            effect.stat_change.forEach(change => {
                const target = change.target === 'self' ? attacker : defender;
                if (target.hp > 0 && Math.random() * 100 <= change.chance) { // Secondary effects usually only if target alive
                    target.applyStage(change.stat, change.stage);
                    this.log(`${target.name} の ${change.stat} が変化した！`);
                }
            });
        }
        // Status secondary effect
        if (effect.status_ailment) {
            this.tryInflictStatus(defender, effect.status_ailment.name, effect.status_ailment.chance);
        }
    }

    tryInflictStatus(target, statusName, chance) {
        if (target.status) return; // Already has status
        if (Math.random() * 100 > chance) return;

        // Type Immunities for Status
        if (statusName === 'poison' || statusName === 'bad_poison') {
            if (target.types.includes('どく') || target.types.includes('はがね')) {
                // Ability: ふしょく (Corrosion) - Not implemented here, handled at source usually, but let's assume standard only
                return;
            }
        }
        if (statusName === 'burn' && target.types.includes('ほのお')) return;
        if (statusName === 'paralysis' && target.types.includes('でんき')) return;
        if (statusName === 'freeze' && target.types.includes('こおり')) return;

        // Apply
        target.status = { name: statusName };
        if (statusName === 'sleep') {
            target.statusParams.sleepTurns = 2 + Math.floor(Math.random() * 3); // 2-4 turns
            this.log(`${target.name} は眠ってしまった！`);
        } else if (statusName === 'poison') {
            this.log(`${target.name} は毒を浴びた！`);
        } else if (statusName === 'bad_poison') {
            target.statusParams.turnCount = 0;
            this.log(`${target.name} は猛毒を浴びた！`);
        } else if (statusName === 'burn') {
            this.log(`${target.name} はやけどを負った！`);
        } else if (statusName === 'paralysis') {
            this.log(`${target.name} はまひしてしまった！`);
        } else if (statusName === 'freeze') {
            this.log(`${target.name} はこおりついてしまった！`);
        }
    }

    endTurn() {
        this.log("--- ターン終了 ---");

        [this.p1.active, this.p2.active].forEach(mon => {
            if (mon.hp <= 0) return;

            // Weather Damage
            if (this.weather === 'sand' && !mon.types.includes('いわ') && !mon.types.includes('じめん') && !mon.types.includes('はがね')) {
                const dmg = Math.floor(mon.maxHp / 16);
                mon.hp = Math.max(0, mon.hp - dmg);
                this.log(`すなあらしが ${mon.name} をおそう！`);
            }

            // Status Damage
            if (mon.status?.name === 'poison') {
                const dmg = Math.floor(mon.maxHp / 8);
                mon.hp = Math.max(0, mon.hp - dmg);
                this.log(`${mon.name} は毒のダメージを受けている！`);
            }
            if (mon.status?.name === 'burn') {
                const dmg = Math.floor(mon.maxHp / 16);
                mon.hp = Math.max(0, mon.hp - dmg);
                this.log(`${mon.name} はやけどのダメージを受けている！`);
            }
            // Bad Poison (1/16, 2/16, ...)
            if (mon.status?.name === 'bad_poison') {
                mon.statusParams.turnCount++;
                const dmg = Math.floor(mon.maxHp * mon.statusParams.turnCount / 16);
                mon.hp = Math.max(0, mon.hp - dmg);
                this.log(`${mon.name} は毒のダメージを受けている！`);
            }
        });

        this.checkFainted(this.p1.active);
        this.checkFainted(this.p2.active);
    }

    checkFainted(mon) {
        if (mon.hp <= 0) {
            this.log(`${mon.name} は たおれた！`);
            return true;
        }
        return false;
    }
}
