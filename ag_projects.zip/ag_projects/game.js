/**
 * Game Controller
 */

// Global State
let currentPlayerName = "";
let currentRoomId = null;
let currentRole = null; // 'host' or 'guest'
let myTeam = []; // Array of Pokemon Objects (initially data, then instantiated)
let battleInstance = null;

// UI Elements
const views = {
    login: document.getElementById('login-view'),
    lobby: document.getElementById('lobby-view'),
    teambuilder: document.getElementById('teambuilder-view'),
    battle: document.getElementById('battle-view')
};

function switchView(viewName) {
    Object.values(views).forEach(el => el.classList.remove('active'));
    views[viewName].classList.add('active');
}

// --- Login ---
document.getElementById('start-btn').addEventListener('click', () => {
    const name = document.getElementById('player-name-input').value;
    if (name) {
        currentPlayerName = name;
        switchView('lobby');
    }
});

// --- Lobby ---
document.getElementById('create-room-btn').addEventListener('click', () => {
    const password = document.getElementById('room-password-input').value;
    if (!password) return alert("パスワードを設定してください");

    Network.createRoom(currentPlayerName, password, (roomId) => {
        currentRoomId = roomId;
        currentRole = 'host';
        document.getElementById('lobby-status').innerText = `部屋ID: ${roomId} 待機中...`;
        // Listen for join
        Network.waitForOpponent(roomId, () => {
            switchView('teambuilder');
            initTeamBuilder();
        });
    });
});

document.getElementById('join-room-btn').addEventListener('click', () => {
    const password = document.getElementById('room-password-input').value;
    if (!password) return alert("パスワードを入力してください");

    // In a real app we might list rooms, here we assume user knows ID or we search/match
    // For simplicity, let's ask for Room ID via prompt or assume a fixed logic if we implemented listing.
    // The spec says "パスワードを打ち込んでほかのプレーヤーが部屋に入ってきたら" which implies finding the room by password? 
    // Usually Firebase requires known keys. Let's do a simple scan or prompt for ID. 
    // Since spec is vague on "finding", I'll implement a simple "Find room with this password"

    document.getElementById('lobby-status').innerText = "部屋を探しています...";
    Network.findRoomByPassword(password, (roomId) => {
        if (roomId) {
            currentRoomId = roomId;
            currentRole = 'guest';
            Network.joinRoom(roomId, currentPlayerName, () => {
                switchView('teambuilder');
                initTeamBuilder();
            });
        } else {
            alert("部屋が見つかりませんでした");
        }
    });
});

// --- Team Builder ---
let selectedPokemonIds = [];

function initTeamBuilder() {
    const container = document.getElementById('pokemon-selection-list');
    container.innerHTML = '';

    Object.values(pokemonData).forEach(p => {
        const div = document.createElement('div');
        div.className = 'pokemon-card';
        div.innerText = `${p.icon} ${p.name}`;
        div.onclick = () => togglePokemonSelection(p.id, div);
        container.appendChild(div);
    });
}

function togglePokemonSelection(id, div) {
    if (selectedPokemonIds.includes(id)) {
        selectedPokemonIds = selectedPokemonIds.filter(i => i !== id);
        div.classList.remove('selected');
    } else {
        if (selectedPokemonIds.length < 3) {
            selectedPokemonIds.push(id);
            div.classList.add('selected');
        }
    }

    updateTeamList();

    if (selectedPokemonIds.length === 3) {
        document.getElementById('selected-team-list').innerHTML = ''; // wait for move selection flow?
        // Spec says: "pokemonごとにに覚えさせる技を...4つずつ選択します"
        // Let's simplified flow: After selecting 3, show editor for each.
        startMoveSelection();
    }
}

let editingPokemonIndex = 0;
let finalTeamData = [];

function startMoveSelection() {
    document.getElementById('pokemon-selection-list').style.display = 'none';
    document.getElementById('current-pokemon-editor').style.display = 'block';
    showMoveEditor(selectedPokemonIds[0]);
}

function showMoveEditor(pokeId) {
    const pData = pokemonData[pokeId];
    document.getElementById('editor-pokemon-name').innerText = `${pData.name} の技選択`;
    const moveContainer = document.getElementById('move-selection-list');
    moveContainer.innerHTML = '';

    // Show all moves? Spec says "pokemonごとに覚えることのできる技は決まっています"
    // But move_list.js is just a big list. I should filter?
    // The move_list.js has types. Maybe filter by type? 
    // Or just show ALL moves for now since mapping isn't provided?
    // Wait, the spec says "pokemonごとに覚えることのできる技は決まっています" but provided files don't seem to have a mapping of Pokemon -> Moves.
    // pokemonData in data.js doesn't have moves list.
    // I will enable ALL moves for now or filter by type (Same type + Normal?).
    // Let's filter: Moves of Pokemon's type + Normal moves.

    const availableMoves = pokemonMoves.filter(m =>
        pData.types.includes(m.type) || m.type === 'ノーマル'
    );

    let selectedMoves = [];

    availableMoves.forEach((move, idx) => {
        const div = document.createElement('div');
        div.className = 'move-option';
        div.innerHTML = `<input type="checkbox" id="mv-${idx}" name="moves"> ${move.type} / ${move.name}`;
        const chk = div.querySelector('input');
        chk.onchange = () => {
            if (chk.checked) {
                if (selectedMoves.length >= 4) {
                    chk.checked = false;
                    return;
                }
                selectedMoves.push(move);
            } else {
                selectedMoves = selectedMoves.filter(m => m !== move);
            }
        };
        moveContainer.appendChild(div);
    });

    const btn = document.getElementById('confirm-pokemon-btn');
    btn.onclick = () => {
        if (selectedMoves.length !== 4) return alert("技を4つ選んでください");

        // Save
        finalTeamData.push(new Pokemon(pokeId, selectedMoves));

        editingPokemonIndex++;
        if (editingPokemonIndex < 3) {
            showMoveEditor(selectedPokemonIds[editingPokemonIndex]);
        } else {
            // Done
            finishTeamBuilding();
        }
    };
}

function updateTeamList() {
    // Visual update if needed
}

function finishTeamBuilding() {
    document.getElementById('current-pokemon-editor').style.display = 'none';
    const list = document.getElementById('selected-team-list');
    finalTeamData.forEach(p => {
        const li = document.createElement('li');
        li.innerText = `${p.name} (${p.moves.map(m => m.name).join(', ')})`;
        list.appendChild(li);
    });

    const btn = document.getElementById('finalize-team-btn');
    btn.disabled = false;
    btn.addEventListener('click', () => {
        btn.innerText = "待機中...";
        btn.disabled = true;

        // Sync Team to Firebase
        // We need to serialize the Pokemon objects (simplified)
        // Since Class instances don't JSON stringify methods, we pass data.
        // But Battle class reconstructs? No, we just need to pass the config (ID + Move Names/IDs).
        // Let's pass the full object structure for simplicity.
        Network.submitTeam(currentRoomId, currentRole, finalTeamData);
    });
}
