/**
 * Network Controller using Firebase
 */
const Network = {
    db: null,

    init: () => {
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }
        Network.db = firebase.database();
    },

    createRoom: (hostName, password, callback) => {
        Network.init();
        const roomId = Network.generateId();
        const roomRef = Network.db.ref('rooms/' + roomId);

        roomRef.set({
            password: password,
            host: { name: hostName, status: 'preparing' },
            guest: null,
            state: 'lobby'
        }).then(() => {
            callback(roomId);
        });
    },

    generateId: () => {
        return Math.random().toString(36).substr(2, 6).toUpperCase();
    },

    findRoomByPassword: (password, callback) => {
        Network.init();
        const ref = Network.db.ref('rooms');
        ref.orderByChild('password').equalTo(password).once('value', (snapshot) => {
            const data = snapshot.val();
            if (data) {
                // Return the first matching room
                const roomId = Object.keys(data)[0];
                callback(roomId);
            } else {
                callback(null);
            }
        });
    },

    joinRoom: (roomId, guestName, callback) => {
        const roomRef = Network.db.ref('rooms/' + roomId);
        roomRef.child('guest').set({
            name: guestName,
            status: 'preparing'
        }).then(() => {
            callback();
        });
    },

    waitForOpponent: (roomId, callback) => {
        const roomRef = Network.db.ref('rooms/' + roomId + '/guest');
        roomRef.on('value', (snapshot) => {
            if (snapshot.val()) {
                roomRef.off();
                callback();
            }
        });
    },

    submitTeam: (roomId, role, teamData) => {
        // We serialize the team to plain JSON to avoid recursion/class issues
        const cleanTeam = teamData.map(p => ({
            id: p.id,
            moves: p.moves // Assumed plain objects from move_list
        }));

        Network.db.ref(`rooms/${roomId}/${role}/team`).set(cleanTeam);
        Network.db.ref(`rooms/${roomId}/${role}/status`).set('ready');

        Network.checkStartBattle(roomId, role);
    },

    checkStartBattle: (roomId, myRole) => {
        const roomRef = Network.db.ref(`rooms/${roomId}`);
        roomRef.on('value', snapshot => {
            const data = snapshot.val();
            if (data && data.host && data.host.status === 'ready' && data.guest && data.guest.status === 'ready') {
                roomRef.off();
                // Both ready. Start Loop.
                // We need to initialize the battle locally.
                // But who runs the logic?
                // Peer-to-peer logic: Both run it? Or Host runs it?
                // For simplicity: Both run it mirroring actions.
                // We need to fetch opponent team.
                const myTeam = data[myRole].team;
                const oppRole = myRole === 'host' ? 'guest' : 'host';
                const oppTeam = data[oppRole].team;

                Network.startBattleListener(roomId, myRole, myTeam, oppTeam);
            }
        });
    },

    startBattleListener: (roomId, myRole, myTeamRaw, oppTeamRaw) => {
        // Reconstruct classes
        const rebuild = (raw) => raw.map(d => new Pokemon(d.id, d.moves));
        const p1Team = myRole === 'host' ? rebuild(myTeamRaw) : rebuild(oppTeamRaw);
        const p2Team = myRole === 'host' ? rebuild(oppTeamRaw) : rebuild(myTeamRaw); // p2 is guest usually in my head, but let's stick to standard: P1=Host, P2=Guest

        // Actually wait, Battle(p1, p2). 
        // If I am Host, I am P1. If I am Guest, I am P2.

        // Instantiate Battle
        // Important: Battle logic is deterministic. If both feed same inputs, they get same state.
        // We just need to sync inputs.

        // Switch to Battle View
        switchView('battle');

        // Create Battle Instance
        // Note: Battle constructor expects P1 team, P2 team.
        // Let's assume Host=P1, Guest=P2 globally.
        const hostTeam = myRole === 'host' ? rebuild(myTeamRaw) : rebuild(oppTeamRaw);
        const guestTeam = myRole === 'guest' ? rebuild(myTeamRaw) : rebuild(oppTeamRaw);

        battleInstance = new Battle(hostTeam, guestTeam, (msg) => {
            const log = document.getElementById('battle-log');
            const p = document.createElement('div');
            p.innerText = msg;
            log.prepend(p);
        });

        // Add Listener for Turns
        const turnRef = Network.db.ref(`rooms/${roomId}/turns`);
        turnRef.on('child_added', snapshot => {
            const turnData = snapshot.val();
            // turnData should have { host: action, guest: action }
            // When we get a full turn data, we execute resolveTurn

            if (turnData.host && turnData.guest) {
                battleInstance.resolveTurn(turnData.host, turnData.guest);
                updateBattleUI(myRole);
                // Clear inputs
                disableControls(false);
            }
        });

        updateBattleUI(myRole);
        setupControls(roomId, myRole);
    }
};

function setupControls(roomId, myRole) {
    const btns = document.querySelectorAll('.move-btn');
    btns.forEach((btn, idx) => {
        btn.onclick = () => {
            sendAction(roomId, myRole, { type: 'move', index: idx });
        };
    });

    // Switch logic would go here
}

function sendAction(roomId, role, action) {
    disableControls(true);
    const turnNum = battleInstance.turn + 1;
    Network.db.ref(`rooms/${roomId}/turns/${turnNum}/${role}`).set(action);

    // Waiting text
    const log = document.getElementById('battle-log');
    const p = document.createElement('div');
    p.innerText = "相手の行動を待っています...";
    log.prepend(p);
}

function disableControls(disabled) {
    const btns = document.querySelectorAll('button');
    btns.forEach(b => b.disabled = disabled);
}

function updateBattleUI(myRole) {
    // Sync HP bars, names, etc
    const p1 = battleInstance.p1.active;
    const p2 = battleInstance.p2.active;

    // If I am Host(P1), Self is P1, Opp is P2
    // If I am Guest(P2), Self is P2, Opp is P1
    const self = myRole === 'host' ? p1 : p2;
    const opp = myRole === 'host' ? p2 : p1;

    document.getElementById('self-pokemon-name').innerText = self.name;
    document.getElementById('self-hp-text').innerText = `${self.hp}/${self.maxHp}`;
    document.getElementById('self-hp-bar').style.width = `${(self.hp / self.maxHp) * 100}%`;

    document.getElementById('opponent-pokemon-name').innerText = opp.name;
    document.getElementById('opponent-hp-bar').style.width = `${(opp.hp / opp.maxHp) * 100}%`;

    // Update Moves
    const btns = document.querySelectorAll('.move-btn');
    self.moves.forEach((m, i) => {
        if (btns[i]) btns[i].innerText = `${m.name} (${m.type})`;
    });
}
